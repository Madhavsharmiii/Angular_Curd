import { Component } from '@angular/core';
import { ThemeService } from '../services/theme.service';

@Component({
  selector: 'app-theme',
  templateUrl: './theme.component.html',
  styleUrls: [ ]
})
export class ThemeComponent {
  arr = ["madhav","jai"];
  constructor(public themeService: ThemeService){}
   oldArr = [...this.arr].sort();
  //  newArr = this.arr.toSorted();//no xopy needed
newRev = [...this.arr].reverse();
// newRevv = this.arr.toReversed();//no copy needed
newsplice = [...this.arr].splice(0,2);
// newsplice = arr.toSpliced(0,1);//no copy needed
  toggleTheme(){
    this.themeService.toggleTheme();
  }

}


// // Array.with(index,value);
// const arr = ["radha", "krishna"];
// //OLD WAY
// const newArr = [...arr];
// newArr[1] = "Indiran";
// //NEW WAY
// const newArr2 = arr.with(1,"Indiran");