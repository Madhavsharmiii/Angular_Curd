import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { EmployeeService } from '../services/employee.service';
import { DialogRef } from '@angular/cdk/dialog';
import { CoreService } from '../core/core.service';
@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.scss']
})
export class EmpAddEditComponent implements OnInit {
  empForm!: FormGroup;
  myObject = [];
  begins!: number;
  end!: number;
  timeArray: number[] = [];

  education: string[] = [
    "Matric",
    "Diploma",
    "Intermediate",
    "Graduate",
    "Post Graduation",
  ]
  gender: string[] = [
    "Male",
    "Female",
    "others"
  ]
  constructor(private fb: FormBuilder, private empService: EmployeeService, private dialog: MatDialogRef<EmpAddEditComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private coreService: CoreService) {}
  ngOnInit(): void {
    this.startTime();
    const startTime = performance.now();
    console.log(startTime);
    this.empForm = this.fb.group({
      
      firstName: ['',this.timeArray],
      lastName: '',
      email: '',
      dob: '',
      gender: '',
      education: '',
      company: '',
      experience: '',
      package: '',
      fieldsTimeTaken: [this.timeArray]
    })
    this.empForm.patchValue(this.data);
    const endTime = performance.now();
    console.log(endTime);
    const timeTaken = endTime - startTime;
    console.log(`Time taken to calculate field: ${timeTaken} milliseconds`);
  }
  startTime(){
    this.begins = performance.now();
    console.log("Start Time"+"  "+this.begins);
  }
  endTime(val:any){
    this.end = performance.now();
    console.log("End Time"+"  "+this.end);
    const timeTaken =  this.end-this.begins;
    console.log('Time taken',timeTaken +"  "+"milliseconds");
    let data:any={
      label:val,
      time:timeTaken
    }
    this.timeArray.push(data);
    console.log(this.timeArray);
  }
  onFormSubmit() {
    if (this.empForm.valid) {
      if (this.data) {
        this.empService.updateEmployee(this.data.id, this.empForm.value).subscribe({
          next: (val: any) => {
            this.coreService.openSnackBar("Employee detail Updated Successfully!", 'done');
            this.dialog.close(true);
          },
          error: (err: any) => {
            console.error(err);
          }
        })
      } else {
        console.log(this.empForm.value);
        this.empService.addEmployee(this.empForm.value).subscribe({
          next: (val: any) => {
            this.coreService.openSnackBar("Employee detail Updated Successfully!", 'done')
            this.dialog.close(true);
          },
          error: (err: any) => {
            console.error(err);
          }
        })
      }
    }
  }
}
